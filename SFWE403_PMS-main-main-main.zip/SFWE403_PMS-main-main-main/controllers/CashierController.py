from models.Staff import Cashier

class CashierController:
    def __init__():
        pass

    def main():
        pass
        