from models.Staff import PharmacistTechnician

class PharmacyTechnicianController:
    def __init__(self):
        pass

    